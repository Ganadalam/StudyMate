'use strict';
const bcrypt = require('bcryptjs');
const jwt    = require('jsonwebtoken');
const db     = require('../models/db');

/* ── JWT 설정 ──────────────────────────────────────────── */
const SECRET = (() => {
  const s = process.env.JWT_SECRET;
  if (!s) {
    if (process.env.NODE_ENV === 'production') {
      console.error('[FATAL] JWT_SECRET 환경변수가 설정되지 않았습니다. 서버를 종료합니다.');
      process.exit(1);
    }
    console.warn('[WARN] JWT_SECRET 미설정. 개발용 임시 시크릿 사용 중.');
    return 'studymate_dev_secret_DO_NOT_USE_IN_PRODUCTION';
  }
  return s;
})();
const EXPIRES_IN  = process.env.JWT_EXPIRES || '12h';

/* ── 입력 검증 상수 ─────────────────────────────────────── */
const USERNAME_RE = /^[a-zA-Z0-9_]{3,20}$/;
const MAX_INPUT   = 200;

/* ── 토큰 생성 ──────────────────────────────────────────── */
function makeToken(user) {
  return jwt.sign(
    {
      id:       user.id,
      username: user.username,
      role:     user.role,
      team:     user.team     || '',
      name:     user.display_name || user.username,
    },
    SECRET,
    { expiresIn: EXPIRES_IN }
  );
}

/* ── 입력 새니타이즈 ─────────────────────────────────────── */
function sanitize(str) {
  return String(str || '').trim().slice(0, MAX_INPUT);
}

/* ── 로그인 ─────────────────────────────────────────────── */
exports.login = (req, res) => {
  const username = sanitize(req.body.username);
  const password = sanitize(req.body.password);

  if (!username || !password)
    return res.status(400).json({ error: '아이디와 비밀번호를 입력해주세요.' });

  // timing-safe: 사용자 존재 여부에 상관없이 동일 시간 소요
  const user = db.prepare(
    'SELECT * FROM users WHERE username=? AND username NOT LIKE \'__deleted_%\''
  ).get(username);

  if (!user) {
    // 사용자 없어도 bcrypt 시간 소요 (timing attack 방어)
    bcrypt.compareSync('dummy', '$2a$12$dummyhashfortimingreference000000000000000000000000000');
    return res.status(401).json({ error: '아이디 또는 비밀번호가 올바르지 않습니다.' });
  }

  if (!bcrypt.compareSync(password, user.password))
    return res.status(401).json({ error: '아이디 또는 비밀번호가 올바르지 않습니다.' });

  res.json({
    token:        makeToken(user),
    role:         user.role,
    username:     user.username,
    display_name: user.display_name || user.username,
    team:         user.team || '',
  });
};

/* ── 회원가입 ───────────────────────────────────────────── */
exports.register = (req, res) => {
  const username = sanitize(req.body.username);
  const password = sanitize(req.body.password);
  const team     = sanitize(req.body.team);

  if (!username || !password)
    return res.status(400).json({ error: '아이디와 비밀번호를 입력해주세요.' });
  if (!USERNAME_RE.test(username))
    return res.status(400).json({ error: '아이디는 3~20자 영문·숫자·_만 사용 가능합니다.' });
  if (password.length < 8)
    return res.status(400).json({ error: '비밀번호는 8자 이상이어야 합니다.' });
  if (password.length > 72)
    return res.status(400).json({ error: '비밀번호가 너무 깁니다.' });

  const exists = db.prepare('SELECT id FROM users WHERE username=?').get(username);
  if (exists) return res.status(409).json({ error: '이미 사용 중인 아이디입니다.' });

  const hash = bcrypt.hashSync(password, 12);
  const info = db.prepare(
    'INSERT INTO users(username,password,role,team,display_name) VALUES(?,?,?,?,?)'
  ).run(username, hash, 'user', team, username);

  const newUser = {
    id: info.lastInsertRowid, username, role: 'user',
    team, display_name: username,
  };
  res.status(201).json({
    token:        makeToken(newUser),
    role:         'user',
    username,
    display_name: username,
    team,
  });
};

/* ── 내 정보 ─────────────────────────────────────────────── */
exports.me = (req, res) => {
  const user = db.prepare(
    'SELECT id,username,role,team,display_name,email,created_at FROM users WHERE id=?'
  ).get(req.user.id);
  if (!user) return res.status(404).json({ error: '사용자를 찾을 수 없습니다.' });
  res.json(user);
};

/* ── 프로필 수정 ─────────────────────────────────────────── */
exports.updateProfile = (req, res) => {
  const { team, display_name, email, currentPassword, newPassword } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
  if (!user) return res.status(404).json({ error: '사용자를 찾을 수 없습니다.' });

  const updates = [], params = [];

  if (team         !== undefined) { updates.push('team=?');         params.push(sanitize(team)); }
  if (display_name !== undefined) { updates.push('display_name=?'); params.push(sanitize(display_name)); }
  if (email        !== undefined) {
    const e = sanitize(email);
    if (e && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e))
      return res.status(400).json({ error: '유효하지 않은 이메일 형식입니다.' });
    updates.push('email=?'); params.push(e);
  }

  if (newPassword) {
    if (!currentPassword) return res.status(400).json({ error: '현재 비밀번호를 입력해주세요.' });
    if (!bcrypt.compareSync(sanitize(currentPassword), user.password))
      return res.status(401).json({ error: '현재 비밀번호가 올바르지 않습니다.' });
    const np = sanitize(newPassword);
    if (np.length < 8) return res.status(400).json({ error: '새 비밀번호는 8자 이상이어야 합니다.' });
    if (np.length > 72) return res.status(400).json({ error: '비밀번호가 너무 깁니다.' });
    updates.push('password=?'); params.push(bcrypt.hashSync(np, 12));
  }

  if (!updates.length) return res.status(400).json({ error: '변경할 정보가 없습니다.' });
  params.push(req.user.id);
  db.prepare(`UPDATE users SET ${updates.join(',')} WHERE id=?`).run(...params);

  const updated = db.prepare(
    'SELECT id,username,role,team,display_name,email FROM users WHERE id=?'
  ).get(req.user.id);

  res.json({
    message:      '프로필이 업데이트됐습니다.',
    token:        makeToken(updated),
    team:         updated.team,
    display_name: updated.display_name,
  });
};

/* ── JWT 검증 미들웨어 ──────────────────────────────────── */
exports.verify = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer '))
    return res.status(401).json({ error: '인증이 필요합니다.' });

  const token = authHeader.slice(7);
  // 길이 제한 (너무 긴 토큰 차단)
  if (token.length > 2048)
    return res.status(401).json({ error: '유효하지 않은 토큰입니다.' });

  try {
    req.user = jwt.verify(token, SECRET);
    next();
  } catch (e) {
    const msg = e.name === 'TokenExpiredError'
      ? '세션이 만료됐습니다. 다시 로그인하세요.'
      : '유효하지 않은 토큰입니다.';
    res.status(401).json({ error: msg });
  }
};

/* ── 관리자 권한 체크 ───────────────────────────────────── */
exports.requireAdmin = (req, res, next) => {
  if (req.user?.role !== 'admin')
    return res.status(403).json({ error: '관리자 권한이 필요합니다.' });
  next();
};
