'use strict';
require('dotenv').config({ path: require('path').join(__dirname, '../.env') });

const express = require('express');
const cors    = require('cors');
const path    = require('path');
const crypto  = require('crypto');

const app = express();

/* ── uploads 디렉토리 보장 ────────────────────────────── */
const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!require('fs').existsSync(UPLOAD_DIR))
  require('fs').mkdirSync(UPLOAD_DIR, { recursive: true });

/* ── SECURITY HEADERS (helmet) ─────────────────────────── */
try {
  const helmet = require('helmet');
  // CSP: CDN(flatpickr, chart.js, bootstrap-icons) + 인라인 스크립트 허용
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc:     ["'self'"],
        scriptSrc:      ["'self'", "'unsafe-inline'", "cdn.jsdelivr.net"],
        styleSrc:       ["'self'", "'unsafe-inline'", "cdn.jsdelivr.net"],
        fontSrc:        ["'self'", "cdn.jsdelivr.net"],
        imgSrc:         ["'self'", "data:", "blob:"],
        connectSrc:     ["'self'"],
        frameSrc:       ["'none'"],
        objectSrc:      ["'none'"],
        // upgradeInsecureRequests: 개발환경에서 비활성화
      },
    },
    crossOriginEmbedderPolicy: false,
    // HSTS (HTTPS 강제)
    hsts: process.env.NODE_ENV === 'production'
      ? { maxAge: 31536000, includeSubDomains: true }
      : false,
  }));
} catch (_) {}

/* ── REQUEST LOGGING ───────────────────────────────────── */
try {
  const morgan = require('morgan');
  if (process.env.NODE_ENV === 'production') {
    app.use(morgan('combined'));
  } else {
    app.use(morgan('dev'));
  }
} catch (_) {}

/* ── RATE LIMITING ─────────────────────────────────────── */
try {
  const rL = require('express-rate-limit');

  // 전체 API
  app.use('/api', rL({
    windowMs: 15 * 60 * 1000,
    max: 600,
    standardHeaders: true,
    legacyHeaders:   false,
    message: { error: '요청이 너무 많습니다. 잠시 후 다시 시도해주세요.' },
    skip: (req) => req.method === 'OPTIONS',
  }));

  // 로그인 브루트포스 방어 (15분 내 20회)
  app.use('/api/auth/login', rL({
    windowMs: 15 * 60 * 1000,
    max: 20,
    standardHeaders: true,
    legacyHeaders:   false,
    message: { error: '로그인 시도가 너무 많습니다. 15분 후 다시 시도해주세요.' },
    skipSuccessfulRequests: true,
  }));

  // 회원가입 스팸 방어 (1시간 내 5회)
  app.use('/api/auth/register', rL({
    windowMs: 60 * 60 * 1000,
    max: 5,
    message: { error: '회원가입 요청이 너무 많습니다. 잠시 후 다시 시도해주세요.' },
  }));
} catch (_) {}

/* ── CORS ──────────────────────────────────────────────── */
const CORS_ORIGIN = process.env.CORS_ORIGIN || 'http://localhost:3000';
app.use(cors({
  origin: (origin, cb) => {
    // origin이 없으면 same-origin (서버 내부 요청) → 허용
    if (!origin) return cb(null, true);
    const allowed = CORS_ORIGIN.split(',').map(o => o.trim());
    if (allowed.includes('*') || allowed.includes(origin)) return cb(null, true);
    cb(new Error(`CORS: origin '${origin}' not allowed`));
  },
  credentials: true,
  methods: ['GET','POST','PUT','PATCH','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization'],
}));

/* ── BODY PARSING ──────────────────────────────────────── */
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: false, limit: '2mb' }));

/* ── STATIC FILES ──────────────────────────────────────── */
app.use(express.static(path.join(__dirname, '../public'), {
  maxAge: process.env.NODE_ENV === 'production' ? '1d' : '1h',
  etag:   true,
  // 보안: 숨김 파일(.env 등) 접근 차단
  dotfiles: 'deny',
}));

/* ── ROUTES ────────────────────────────────────────────── */
app.use('/api/auth',          require('./routes/auth'));
app.use('/api/rooms',         require('./routes/room'));
app.use('/api/favorites',     require('./routes/favorite'));
app.use('/api/users',         require('./routes/user'));
app.use('/api/notifications', require('./routes/notification'));
app.use('/api/reservations',  require('./routes/reservation'));
app.use('/api/files',         require('./routes/file'));

/* ── SPA ───────────────────────────────────────────────── */
const sendPage = (f) => (_, res) => res.sendFile(path.join(__dirname, '../public/pages', f));

/* ── FAVICON ──────────────────────────────────────────── */
app.get('/favicon.ico', (_, res) => {
  res.sendFile(path.join(__dirname, '../public/favicon.svg'), {
    headers: { 'Content-Type': 'image/svg+xml', 'Cache-Control': 'public, max-age=86400' }
  });
});
app.get('/',      sendPage('index.html'));
app.get('/user',  sendPage('user.html'));
app.get('/admin', sendPage('admin.html'));

/* ── MULTER ERROR ──────────────────────────────────────── */
app.use((err, req, res, next) => {
  if (err.code === 'LIMIT_FILE_SIZE')
    return res.status(413).json({ error: '파일 크기는 50MB 이하여야 합니다.' });
  if (err.message?.includes('허용되지 않는'))
    return res.status(400).json({ error: err.message });
  next(err);
});

/* ── 404 ───────────────────────────────────────────────── */
app.use((req, res) => {
  if (req.path.startsWith('/api/'))
    return res.status(404).json({ error: `Not found: ${req.method} ${req.path}` });
  res.status(404).sendFile(path.join(__dirname, '../public/pages/index.html'));
});

/* ── 500 ───────────────────────────────────────────────── */
app.use((err, req, res, _next) => {
  const status = err.status || 500;
  // 프로덕션에서 내부 에러 메시지 숨김
  const msg = (process.env.NODE_ENV === 'production' && status >= 500)
    ? '서버 오류가 발생했습니다.'
    : (err.message || '알 수 없는 오류');
  if (status >= 500) console.error('[ERROR]', err.stack || err.message);
  res.status(status).json({ error: msg });
});

/* ── START ─────────────────────────────────────────────── */
const PORT = parseInt(process.env.PORT || '3000', 10);
app.listen(PORT, () => {
  const env = process.env.NODE_ENV || 'development';
  console.log(`\n🚀 StudyMate  →  http://localhost:${PORT}  [${env}]`);
  if (env !== 'production') {
    console.log(`   ℹ️  개발 모드 — 테스트 계정은 브라우저에서 확인하세요`);
    console.log(`   ⚠️  프로덕션 배포 전 .env 파일의 JWT_SECRET을 반드시 변경하세요\n`);
  }
});

module.exports = app;
